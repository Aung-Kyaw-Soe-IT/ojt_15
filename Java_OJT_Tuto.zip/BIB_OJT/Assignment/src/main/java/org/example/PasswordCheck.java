package org.example;
import java.util.Scanner;

public class PasswordCheck {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Step 1: Take password input from user
        System.out.print("Enter your password: ");
        String password = scanner.nextLine();

        // Step 2: Check if password is strong
        if (isStrongPassword(password)) {
            System.out.println("The password is strong.");
        } else {
            System.out.println("The password is weak.");
        }

        scanner.close();
    }

    // Method to check if password is strong
    public static boolean isStrongPassword(String password) {
        // Check length: Password must be greater than 8 characters
        if (password.length() <= 8) {
            return false;
        }

        // Check if password contains at least one lowercase letter, one uppercase letter
        boolean hasLower = false;
        boolean hasUpper = false;
        boolean hasDigit = false;
        boolean hasSpecial = false;

        // Loop through each character of the password
        for (int i = 0; i < password.length(); i++) {
            char ch = password.charAt(i);
            if (Character.isLowerCase(ch)) {
                hasLower = true;
            } else if (Character.isUpperCase(ch)) {
                hasUpper = true;
            } else if (Character.isDigit(ch)) {
                hasDigit = true;
            } else if (isSpecialCharacter(ch)) {
                hasSpecial = true;
            }
        }

        // Check all conditions
        return hasLower && hasUpper && hasDigit && hasSpecial;
    }

    // Method to check if the character is a special character
    public static boolean isSpecialCharacter(char ch) {
        // Special characters can include symbols like !, @, #, $, %, etc.
        return !Character.isLetterOrDigit(ch);
    }

}
