package org.example;
import java.util.Arrays;
import java.util.Scanner;


public class RemoveElementFromArray {
    public static int[] removeElement(int[] arr, int element) {
        int count = 0;

        // Count occurrences of the element
        for (int num : arr) {
            if (num == element) {
                count++;
            }
        }

        // If element is not found, return original array
        if (count == 0) {
            return arr;
        }

        int[] newArr = new int[arr.length - count];
        int index = 0;

        // Copy elements except the specified one
        for (int num : arr) {
            if (num != element) {
                newArr[index++] = num;
            }
        }

        return newArr;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Take array size input
        System.out.print("Enter array size: ");
        int size = scanner.nextInt();

        int[] arr = new int[size];

        // Take array elements input
        System.out.println("Enter array elements:");
        for (int i = 0; i < size; i++) {
            arr[i] = scanner.nextInt();
        }

        // Take element to remove input
        System.out.print("Enter element to remove: ");
        int elementToRemove = scanner.nextInt();

        // Remove element and display the new array
        int[] result = removeElement(arr, elementToRemove);
        System.out.println("Array after removing " + elementToRemove + ": " + Arrays.toString(result));

        scanner.close();
    }
}
