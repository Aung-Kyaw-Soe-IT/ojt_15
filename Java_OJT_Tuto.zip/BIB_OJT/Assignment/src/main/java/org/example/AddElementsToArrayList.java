package org.example;
import java.util.ArrayList;
import java.util.Scanner;

public class AddElementsToArrayList {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Step 1: Create an ArrayList
        ArrayList<String> list = new ArrayList<>();

        // Step 2: Take the number of elements from the user
        System.out.print("Enter the number of elements: ");
        int size = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        // Step 3: Add user input elements to the ArrayList
        System.out.println("Enter " + size + " strings:");
        for (int i = 0; i < size; i++) {
            list.add(scanner.nextLine());
        }

        // Step 4: Print the collection
        System.out.println("ArrayList elements: " + list);

        scanner.close();
    }
}
