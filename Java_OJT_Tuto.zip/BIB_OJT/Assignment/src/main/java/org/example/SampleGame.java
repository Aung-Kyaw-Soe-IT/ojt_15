package org.example;
import java.util.Random;
import java.util.Scanner;

public class SampleGame {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        // Display choices to the user
        System.out.println("Rock-Paper-Scissors Game!");
        System.out.println("Enter your choice:");
        System.out.println("0: Rock, 1: Paper, 2: Scissors");

        // Step 1: Take user input
        int userChoice = scanner.nextInt();

        // Step 2: Generate computer's choice randomly
        int computerChoice = random.nextInt(3); // Random number between 0 and 2

        // Step 3: Display user's and computer's choices
        System.out.println("Your choice: " + choiceToString(userChoice));
        System.out.println("Computer's choice: " + choiceToString(computerChoice));

        // Step 4: Determine the winner
        String result = determineWinner(userChoice, computerChoice);
        System.out.println(result);

        scanner.close();
    }

    // Method to convert choice number to string (Rock, Paper, Scissors)
    public static String choiceToString(int choice) {
        switch (choice) {
            case 0: return "Rock";
            case 1: return "Paper";
            case 2: return "Scissors";
            default: return "Invalid choice";
        }
    }

    // Method to determine the winner
    public static String determineWinner(int user, int computer) {
        if (user == computer) {
            return "It's a draw!";
        }
        switch (user) {
            case 0: // Rock
                return (computer == 1) ? "You lose! Paper covers Rock." : "You win! Rock crushes Scissors.";
            case 1: // Paper
                return (computer == 2) ? "You lose! Scissors cuts Paper." : "You win! Paper covers Rock.";
            case 2: // Scissors
                return (computer == 0) ? "You lose! Rock crushes Scissors." : "You win! Scissors cuts Paper.";
            default:
                return "Invalid choice";
        }
    }
}
