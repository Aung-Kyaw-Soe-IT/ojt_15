package org.example;
import java.util.ArrayList;
import java.util.Scanner;

public class ArrayListToArray {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Step 1: Take the number of elements from the user
        System.out.print("Enter the number of elements: ");
        int size = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        // Step 2: Create an ArrayList and take user input
        ArrayList<String> list = new ArrayList<>();
        System.out.println("Enter " + size + " strings:");
        for (int i = 0; i < size; i++) {
            list.add(scanner.nextLine());
        }

        // Step 3: Convert ArrayList to Array
        String[] array = list.toArray(new String[0]);

        // Step 4: Print the converted array
        System.out.println("Array elements:");
        for (String str : array) {
            System.out.println(str);
        }

        scanner.close();
    }
}
