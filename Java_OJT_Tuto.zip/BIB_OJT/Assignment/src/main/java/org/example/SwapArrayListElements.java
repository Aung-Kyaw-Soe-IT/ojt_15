package org.example;
import java.util.ArrayList;

public class SwapArrayListElements {
    public static void main(String[] args) {
        // Step 1: Create an ArrayList and add elements
        ArrayList<String> list = new ArrayList<>();
        list.add("Apple");
        list.add("Banana");
        list.add("Cherry");
        list.add("Date");
        list.add("Elderberry");

        // Step 2: Swap elements at indices 1 and 3 (for example)
        int index1 = 1;
        int index2 = 3;

        // Swap the elements
        String temp = list.get(index1);
        list.set(index1, list.get(index2));
        list.set(index2, temp);

        // Step 3: Print the updated ArrayList
        System.out.println("Updated ArrayList: " + list);
    }
}
