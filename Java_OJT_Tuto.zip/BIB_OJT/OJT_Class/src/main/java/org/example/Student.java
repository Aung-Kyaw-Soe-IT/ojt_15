package org.example;

public class Student {
    String name;
    String age;
    String gender;
    //Methods
    public void info(){
        System.out.println("Name: " + name + " Age: " + age + " Gender: " + gender);
    }
//    Student(String name,String age){
//        this.name=name;
//        this.age=age;
//    }

    public static void main(String[] args) {
        Student s = new Student();
        s.name = "John";
        s.age = "23";
        s.gender = "male";
        s.info();

//        Student s2 = new Student("John","23");
//        s2.info();
    }
}


