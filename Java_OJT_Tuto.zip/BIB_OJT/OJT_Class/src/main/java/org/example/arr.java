package org.example;

import java.util.ArrayList;

public class arr {
    public static void main(String[] args) {
        int [ ] newArr={1,2,3,4,5};
        for(int j=0;j<newArr.length;j++){
            System.out.println(newArr[j]);
        }

        String [] name={"Aung","Kyaw","Soe"};
        for(String index:name){
            System.out.println(index);
        }
        int[][] multiArr={{1,2,3},{4,5,6},{7,8,9}};

            System.out.println(multiArr[0][1]);


            ArrayList<String> arrList=new ArrayList<String>();
            //can use add & remove
        arrList.add("Live");
        arrList.add("Mandalay");
        for(String value:arrList){
            System.out.print(value +" ");
        }

       
    }
}
